import turtle

t = turtle.Turtle()
t.speed(6)

colors = ["red", "blue", "pink", "yellow"]
for i in range(1000):
    t.color(colors[i%4])
    t.pensize(3)
    i+=5
    t.forward(i)
    t.right(61)

turtle.done()