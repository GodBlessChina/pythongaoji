"""
numpy pandas 绘图 综合练习
"""
import turtle
import numpy as np
import pandas as pd

YUANDIAN_X = -2120/3
YUANDIAN_Y = -1280/3
ZHOU_LENGTH = 1300 # x轴、y轴的长度

# 先画坐标系
screen = turtle.Screen()
screen.setup(width=1.0, height=1.0)

# turtle.screensize(1920, 1080)
t = turtle.Turtle()
t.speed(0) # 速度

t.up()
t.goto(YUANDIAN_X, YUANDIAN_Y)
t.down()
t.forward(ZHOU_LENGTH) # x轴
t.backward(ZHOU_LENGTH)

# x轴上的刻度
for i in range(25):
    t.forward(50)
    t.left(90)
    t.forward(10)
    t.backward(10)
    t.right(90)
# 回到原点(坐标系的原点，不是默认的原点0,0)
t.goto(YUANDIAN_X, YUANDIAN_Y)

t.left(90)

t.forward(ZHOU_LENGTH-500) # y轴

t.goto(YUANDIAN_X,YUANDIAN_Y)

# y的刻度
for i in range(15):
    t.forward(50)
    t.right(90)
    t.forward(10)
    t.backward(10)
    t.left(90)

# 回到原点
t.goto(YUANDIAN_X,YUANDIAN_Y)
t.right(90)

# x轴的刻度说明
for i in range(25):
    t.forward(50)
    t.right(90)
    t.up()
    t.forward(30)
    t.down()
    t.write(i+1,font=("",15))
    t.up()
    t.backward(30)
    t.left(90)

# 回到原点
t.goto(YUANDIAN_X,YUANDIAN_Y)
t.left(90)

# y轴上的刻度说明
for i in range(15):
    t.forward(50)
    t.left(90)
    t.up()
    t.forward(30)
    t.down()
    t.write(i+1,font=("",15))
    t.up()
    t.backward(30)
    t.right(90)


# 读取 "股价.txt" 文件
f = open("股价.txt", mode='r', encoding='utf-8')
# 获取每一行数据 迭代f
# 前面3行不需要
f.readline()
f.readline()
f.readline()

# 回到原点
t.goto(YUANDIAN_X,YUANDIAN_Y)
t.down()

x_distance = YUANDIAN_X
for hang in f:
    hang = hang.replace('\n', '')
    shuzi = float(hang) # 强制转换成小数
    print(hang)  # 6.95 #一个一个的数字，
    # 画折线图
    t.speed(1)
    t.goto(x_distance,shuzi*30)
    x_distance += 50


turtle.done() # 显示图像