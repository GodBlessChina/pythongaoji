import turtle

t = turtle.Turtle()
t.speed(6)

for i in range(10):
    t.circle(i*10)
    t.up()
    t.goto(0, -i*10)
    t.down()

# t.circle(10)
# t.up()
# t.goto(0,-10)
# t.down()
#
# t.circle(20)
# t.up()
# t.goto(0,-20)
# t.down()
#
# t.circle(30)

turtle.done()