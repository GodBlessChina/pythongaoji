"""
600004.SH
白云机场
开盘价
6.9500
6.9400
6.9400
6.9400
6.9400
6.8500
6.9400
"""

import numpy as np

arr= np.linspace(6.9500,7.9500,25)
for line in arr:
    print(line)

