f = open("股价.txt", mode='r', encoding='utf-8')
# 获取每一行数据 迭代f
# 前面3行不需要
f.readline()
f.readline()
f.readline()

for hang in f:
    hang = hang.replace('\n', '')
    shuzi = float(hang)  # 强制转换成小数
    print(hang)  # '6.95'

# lines = f.readlines()[3:]
# for line in lines:
#     print(line)
