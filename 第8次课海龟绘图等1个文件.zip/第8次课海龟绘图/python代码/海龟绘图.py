import turtle

t = turtle.Turtle()
t.speed(6)

for i in range(4):
    t.forward(200)  # 箭头默认朝向右边
    t.right(90)

# t.forward(200) # 箭头默认朝向右边
# t.right(90) # 向右转90度
#
# t.forward(200)
# t.right(90)
#
# t.forward(200)
# t.right(90)
#
# t.forward(200)

turtle.done()