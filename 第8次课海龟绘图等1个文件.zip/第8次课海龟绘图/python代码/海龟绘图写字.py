import turtle

t = turtle.Turtle()
t.speed(1)

t.forward(100)
# t.write("你好",font=("Arial",20))  # 在界面上写字
t.write("你好",font=("",20))  # 在界面上写字 默认字体
t.backward(50)

turtle.done()