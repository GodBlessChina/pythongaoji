import turtle

t = turtle.Turtle()
t.speed(6)

t.up()
t.goto(-300,-300)
t.down()

for i in range(20):
    t.forward(20)
    t.left(90)
    t.forward(20)
    t.right(90)

# t.forward(50)
# t.left(90)
# t.forward(50)
# t.right(90)
#
# t.forward(50)
# t.left(90)
# t.forward(50)
# t.right(90)
#
# t.forward(50)
# t.left(90)
# t.forward(50)
# t.right(90)

# t.go
# t.forward(200) # 箭头默认朝向右边
# t.right(90)
# t.up() # 笔抬起来
# t.forward(100)
# t.down() # 笔放下去
# t.right(90)
# t.forward(200)

turtle.done()