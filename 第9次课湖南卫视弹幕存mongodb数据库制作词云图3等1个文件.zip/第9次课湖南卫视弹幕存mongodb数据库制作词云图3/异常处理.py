# ctrl + alt +t
try:
    print(1/0)
    open("1111.txt")
except ZeroDivisionError:
    print("0不能作为分母")
except FileNotFoundError:
    print("文件没找到")
finally:
    print()
print("hello")