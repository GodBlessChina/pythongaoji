from pyecharts.charts import WordCloud
import pandas as pd

df = pd.read_csv("弹幕.csv") # DataFrame对象
words = list(df['词语'].values)
num = list(df['频数'].values)
data = [k for k in zip(words,num)]
print(words)  # ['没错', '女孩子', '确实', '大老师']
print(num)    # [10, 20, 5, 50]
print(data)   # [('没错', 10), ('女孩子', 20), ('确实', 5), ('大老师', 50)]

# 将csv文件处理成 [('没错', 10), ('女孩子', 20), ('确实', 5), ('大老师', 50)] 这种格式，
# 就可以制作云图了