arr1 = ['我', '好帅', '花花','老师', '啦', '还是', '一样', '老师', '啦','的', '拽', '呀']
arr2 = ['来看', '好帅', '大', '老师', '啦', ' ', '啊啊啊', '好帅']
# 老师:3

d = {}
for key in arr1:
    if d.keys().__contains__(key):
        d[key] = d[key]+1
    else:
        d[key]=1
print(d)