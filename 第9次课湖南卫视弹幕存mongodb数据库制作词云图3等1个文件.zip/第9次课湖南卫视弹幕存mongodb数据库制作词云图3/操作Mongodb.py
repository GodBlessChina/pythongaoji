import pymongo   # pip install pymongo  mongodb是非关系型数据库 Nosql

# 创建了一个MongoDB客户端对象，用这个对象，可以进行添加数据、删除数据等等操作  127.0.0.1本机 27017MongoDB端口
client = pymongo.MongoClient("127.0.0.1",27017)  # 27017是mongo的默认端口，  3306mysql  8080/80  22  20
db_hkz = client['hkz']  # 连接到数据库hkz,如果这个数据库不存在，就创建，如果存在就连接
collection_rj5 = db_hkz['rj5']  # 创建一个【集合】(类似sql数据库的表格)  db_hkz.rj5
# 添加数据 _id主键唯一  ctrl+alt+T
try:
    collection_rj5.insert_one({"_id":1,"name":"张三", "age":19})
except pymongo.errors.DuplicateKeyError:
    print("这个数据存在了，不能反复添加")

# 查看数据
res = collection_rj5.find() # 查询所有的数据
for r in res:
    print(r)
