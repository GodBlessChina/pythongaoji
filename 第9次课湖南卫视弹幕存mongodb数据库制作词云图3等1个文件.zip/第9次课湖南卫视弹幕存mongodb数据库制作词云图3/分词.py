import jieba

s = "你好你好世界世界苏醒苏醒我来啦"
w = jieba.lcut(s)
print(w)