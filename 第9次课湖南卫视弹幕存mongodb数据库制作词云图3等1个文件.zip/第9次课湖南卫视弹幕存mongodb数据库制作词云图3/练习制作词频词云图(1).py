# 练习： 制作词频词云图
"""
1 爬取网络评论
2 存储到数据库
3 制作云图
"""
import requests  # 做网络请求的包，可以处理一些静态页面  在cmd中 pip install requests
import json
import jieba
import pymongo

client = pymongo.MongoClient("127.0.0.1", 27017)
db_hnws = client['hnws'] # 创建了一个数据库hnws
collection_wxhnc = db_hnws['wxhnc'] #创建了一个集合wxhnc



for i in range(70):
    break
    url = f'https://bullet-ws.hitv.com/bullet/tx/2023/04/11/071526/18611791/{i}.json'  # 湖南卫视 我想和你喝 的弹幕
    res = requests.get(url).text  # 获取文本,理论上是网页的源代码，是字符串类型
    # print(type(res))  # "{'name':'张三'}"
    d = json.loads(res)  # "{'name':'张三'}" --> {'name':'张三'}
    items = d['data']['items']
    for item in items:
        bianhao = item['id']
        neirong = item['content']
        shijian = item['time']
        # 保存数据到MongoDB  _id 主键 唯一
        data = {"_id": bianhao, "neirong": neirong, "shijian": shijian}
        print(f"添加数据:{data}")
        try:
            collection_wxhnc.insert_one(data)
        except pymongo.errors.DuplicateKeyError:
            print("这行数据添加过了，跳过")

# 查询数据库中所有的数据，并且做词云图
docs = collection_wxhnc.find()
word_counts = {}  # 空的字典
for doc in docs:
    # print(doc)  # {'_id': 7219532831832426809, 'neirong': '远远好好用脸！', 'shijian': 4185041}
    # 分词
    ws = jieba.lcut(doc['neirong'])
    print(ws)
    for w in ws:
        if word_counts.keys().__contains__(w):
            word_counts[w] = word_counts[w]+1
        else:
            word_counts[w] = 1
# 统计次数
print(f"所有的词频: {word_counts}")  # {'文文': 7, '一穿': 1, '小裙': 1, '裙': 1, '又': 188 ...
# 生成.csv pyecharts需要特定格式的文本
fcsv = open("我想和你唱第4季.csv", 'w',encoding='utf-8')
fcsv.writelines('词语,频数\n')
for word in word_counts:
    count = word_counts[word]
    print(word,count)
    # 写入csv
    fcsv.writelines(f"{word},{count}\n")
fcsv.close()
# 生成云图

from pyecharts.charts import WordCloud
import pandas as pd
df = pd.read_csv("我想和你唱第4季.csv") # DataFrame对象
words = list(df['词语'].values)
num = list(df['频数'].values)
data = [k for k in zip(words,num)]
print(words)  # ['没错', '女孩子', '确实', '大老师']
print(num)    # [10, 20, 5, 50]
print(data)
